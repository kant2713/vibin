# Vibin

  Social media is an interactive computer-mediated technology that facilitates
the creation or sharing of information, ideas, career interests and other forms of expression via virtual communities and networks.
Motivation: we wanted to build an app which allows you to reach people locally, 
regionally, nationally and even internationally. To provide a platform where 
people can connect with other people around the world. To share their thoughts
and get to know other cultures around the world.
 
  The project has been developed using NodeJS and ExpressJS as Backend and MongoDB as Database and React for the Front- end work.
The user is provided with a database where the information is stored and can be retrieved any time when required. 
Security is maintained for the system, there is a User Mail and Password for an authorized person only that person can access the data in the system.

  The purpose of this project is to develop Online Social Media Application.
The main purpose of this Online Social Media App project is to allow users to post interesting events that happened in their lives.
